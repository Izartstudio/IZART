# Izart Our Services

A reusable Next.js App Router section with a sticky background, click and scroll driven service tabs, a Learn More cursor, and a featured project card. The folder includes five backgrounds and one featured card image.

## Add the component

Merge the supplied `src/` and `public/` directories into your app. Add `90` to `images.qualities` in your Next.js config to enable the component’s higher quality setting. Use the component in the normal page scroll so its stage can pin.

```tsx
import { HomeServices } from "../components/home/services/home-services.client";
import { defaultHomeServices } from "../content/home-services";

export default function Page() {
  return <HomeServices content={defaultHomeServices} />;
}
```

## Connect Sanity

In a project with `sanity`, `@sanity/client`, and `server-only`, register `homeServices` from the included schema. Use the document ID `home-services`. Configure `SANITY_PROJECT_ID` and `SANITY_DATASET` on the site, and set a read token for a private dataset. Add `cdn.sanity.io` under Next.js image remote patterns for `/images/**`.

With the Sanity CLI connected to your dataset, run `sanity exec scripts/import-home-services-to-sanity.ts --with-user-token` to upload the images and create the document. The script preserves any existing document. Pass `await getHomeServices()` from `src/sanity/home-services.ts` to the component's `content` prop.

The sample links use the original Izart route paths. Update the service, project, and industries destinations for your site.
